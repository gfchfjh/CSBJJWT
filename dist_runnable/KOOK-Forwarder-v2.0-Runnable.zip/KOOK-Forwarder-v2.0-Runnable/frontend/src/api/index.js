import axios from 'axios'
import { setupInterceptors } from './interceptors'

const API_BASE_URL = 'http://localhost:9527'

const api = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json'
  }
})

// 请求拦截器
api.interceptors.request.use(
  config => {
    // 添加认证Token
    const token = localStorage.getItem('auth_token')
    if (token) {
      config.headers.Authorization = `Bearer ${token}`
    }
    return config
  },
  error => {
    return Promise.reject(error)
  }
)

// ✅ P0-2优化：使用友好错误提示的响应拦截器
// 注意：这里先处理数据格式，友好错误在setupInterceptors中处理
api.interceptors.response.use(
  response => {
    return response.data
  },
  error => {
    // 不在这里处理错误，让setupInterceptors中的友好错误处理器处理
    return Promise.reject(error)
  }
)

// ✅ P0-2优化：设置友好错误拦截器（在最后执行）
// 注意：这个要在上面的拦截器之后设置，这样可以捕获所有错误
setupInterceptors(api)

export default {
  // 系统
  getSystemStatus: () => api.get('/api/system/status'),
  startService: () => api.post('/api/system/start'),
  stopService: () => api.post('/api/system/stop'),
  getConfig: () => api.get('/api/system/config'),
  
  // 账号
  getAccounts: () => api.get('/api/accounts/'),
  addAccount: (data) => api.post('/api/accounts/', data),
  deleteAccount: (id) => api.delete(`/api/accounts/${id}`),
  startAccount: (id) => api.post(`/api/accounts/${id}/start`),
  stopAccount: (id) => api.post(`/api/accounts/${id}/stop`),
  getServers: (accountId) => api.get(`/api/accounts/${accountId}/servers`),
  getChannels: (accountId, serverId) => api.get(`/api/accounts/${accountId}/servers/${serverId}/channels`),
  getCaptchaStatus: (accountId) => api.get(`/api/accounts/${accountId}/captcha`),
  submitCaptcha: (accountId, code) => api.post(`/api/accounts/${accountId}/captcha`, { code }),
  // ✅ P0-3优化：刷新验证码API
  refreshCaptcha: (accountId) => api.get(`/api/accounts/${accountId}/captcha/refresh`),
  
  // Bot配置
  getBotConfigs: (platform) => api.get('/api/bots/', { params: { platform } }),
  addBotConfig: (data) => api.post('/api/bots/', data),
  addBot: (data) => api.post('/api/bots/', data),  // 别名，用于向导页面
  deleteBotConfig: (id) => api.delete(`/api/bots/${id}`),
  testBotConfig: (id) => api.post(`/api/bots/${id}/test`),
  getTelegramChatIds: (token) => api.get('/api/bots/telegram/chat-ids', { params: { token } }),
  
  // 频道映射
  getMappings: (kookChannelId) => api.get('/api/mappings/', { params: { kook_channel_id: kookChannelId } }),
  addMapping: (data) => api.post('/api/mappings/', data),
  deleteMapping: (id) => api.delete(`/api/mappings/${id}`),
  toggleMapping: (id) => api.put(`/api/mappings/${id}/toggle`),
  exportMappings: () => {
    // 导出文件需要特殊处理
    return axios.get(`${API_BASE_URL}/api/mappings/export`, {
      responseType: 'blob'
    })
  },
  importMappings: (data) => api.post('/api/mappings/import', data),
  importMappingsFromFile: (file) => {
    const formData = new FormData()
    formData.append('file', file)
    return api.post('/api/mappings/import/file', formData, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    })
  },
  
  // 日志
  getLogs: (limit, status) => api.get('/api/logs/', { params: { limit, status } }),
  getStats: () => api.get('/api/logs/stats'),
  getStatsTrend: (hours = 24) => api.get('/api/logs/stats/trend', { params: { hours } }),
  getStatsByPlatform: () => api.get('/api/logs/stats/platforms'),
  exportLogsCSV: (limit, status) => {
    return axios.get(`${API_BASE_URL}/api/logs/export/csv`, {
      params: { limit, status },
      responseType: 'blob'
    })
  },
  exportLogsJSON: (limit, status) => {
    return axios.get(`${API_BASE_URL}/api/logs/export/json`, {
      params: { limit, status },
      responseType: 'blob'
    })
  },
  
  // 过滤规则
  getFilterRules: () => api.get('/api/system/filter-rules'),
  saveFilterRules: (data) => api.post('/api/system/filter-rules', data),
  
  // 智能映射
  suggestMappings: (data) => api.post('/api/smart-mapping/suggest', data),
  applySmartMappings: (suggestions) => api.post('/api/smart-mapping/apply', suggestions),
  previewSmartMapping: (accountId) => api.get(`/api/smart-mapping/preview/${accountId}`),
  
  // 备份恢复
  backupConfig: () => api.post('/api/backup/create'),
  restoreConfig: (data) => api.post('/api/backup/restore', data),
  listBackups: () => api.get('/api/backup/list'),
  
  // 认证与密码
  getAuthStatus: () => api.get('/auth/status'),
  setupPassword: (data) => api.post('/auth/setup', data),
  login: (data) => api.post('/auth/login', data),
  logout: () => api.post('/auth/logout'),
  verifyToken: () => api.post('/auth/verify-token'),
  changePassword: (data) => api.post('/auth/change-password', data),
  resetPassword: (data) => api.post('/auth/reset-password', data),
  generateResetCode: () => api.post('/password-reset/generate-code'),
  // 旧API兼容
  checkPasswordExists: () => api.get('/api/auth/password-exists'),
  setPassword: (data) => api.post('/api/auth/set-password', data),
  verifyPassword: (data) => api.post('/api/auth/verify-password', data),
  
  // 邮件配置
  getEmailConfig: () => api.get('/api/system/email-config'),
  saveEmailConfig: (data) => api.post('/api/system/email-config', data),
  testEmail: () => api.post('/api/system/email-test'),
  
  // 健康检查
  performHealthCheck: () => api.get('/api/health/check'),
  getHealthStatus: () => api.get('/api/health/status'),
  checkSingleBot: (botId) => api.post(`/api/health/check-bot/${botId}`),
  
  // 更新检查
  checkForUpdates: () => api.get('/api/updates/check'),
  getUpdateStatus: () => api.get('/api/updates/status'),
  getLatestVersion: () => api.get('/api/updates/latest'),
  getDownloadUrl: (platform) => api.get(`/api/updates/download/${platform}`),
  
  // 选择器配置
  getSelectorConfig: () => api.get('/api/selectors/config'),
  getCategorySelectors: (category) => api.get(`/api/selectors/category/${category}`),
  updateSelectors: (data) => api.post('/api/selectors/update', data),
  addSelector: (data) => api.post('/api/selectors/add', data),
  removeSelector: (data) => api.post('/api/selectors/remove', data),
  reloadSelectorConfig: () => api.post('/api/selectors/reload'),
  exportSelectorConfig: () => api.get('/api/selectors/export'),
  importSelectorConfig: (data) => api.post('/api/selectors/import', data),
  getSelectorFileInfo: () => api.get('/api/selectors/file-info'),
  
  // 系统配置（新增）
  getSystemConfig: () => api.get('/api/system/system-config'),
  saveSystemConfig: (data) => api.post('/api/system/system-config', data),
  getStorageUsage: () => api.get('/api/system/storage-usage'),
  cleanupImages: (days) => api.post('/api/system/cleanup-images', { days }),
  cleanupLogs: (days) => api.post('/api/system/cleanup-logs', days ? { days } : null),
  getSystemPaths: () => api.get('/api/system/paths')
}
