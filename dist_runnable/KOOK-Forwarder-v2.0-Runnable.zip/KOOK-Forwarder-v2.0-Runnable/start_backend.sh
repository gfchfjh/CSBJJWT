#!/bin/bash
echo "启动KOOK消息转发系统 - 后端服务"
cd backend
python3 -m app.main
