#!/bin/bash
echo "启动KOOK消息转发系统 - 前端界面"
cd frontend
npm run dev
