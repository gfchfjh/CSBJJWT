#!/bin/bash
echo "========================================"
echo "KOOK消息转发系统 v2.0 演示版"
echo "========================================"
echo ""
echo "正在启动后端服务..."
cd backend
python3 -m app.main
